﻿Public Class Form1
    Private Sub btnGenrateProfit_Click(sender As Object, e As EventArgs) Handles btnGenrateProfit.Click
        ' Declaring Variable to store user input from the controls
        Dim intClassA As Integer
        Dim intClassB As Integer
        Dim intClassC As Integer
        Dim AmountClassA As Double
        Dim AmountClassB As Double
        Dim AmountClassC As Double

        ' Creating Constants for each ticket price 
        Const ClassAPrice As Double = 15.0
        Const ClassBPrice As Double = 12.0
        Const ClassCPrice As Double = 9.0

        'Exception block to catch for numerical errors
        Try
            ' Converts each textbox class text into an integer and assigns to 
            ' a inClass* variable
            intClassA = CInt(textboxClassA.Text)
            intClassB = CInt(textboxClassB.Text)
            intClassC = CInt(textboxClassC.Text)

            ' Takes int class varibale and multiply by the ticket price
            ' which store in the ClassPrice* constant
            AmountClassA = (intClassA * ClassAPrice)
            AmountClassB = (intClassB * ClassBPrice)
            AmountClassC = (intClassC * ClassCPrice)

            'Converts AmountClass* variables to currency string and display in
            ' the text of label

            lblAmountClassA.Text = AmountClassA.ToString("C")
            lblAmountClassB.Text = AmountClassB.ToString("C")
            lblAmountClassC.Text = AmountClassC.ToString("C")

            ' Adds each amount class variable and converts the number into a
            'currency string, then display in total amount label

            lblTotalAmount.Text = ((AmountClassA + AmountClassB + AmountClassC).ToString("C"))
        Catch ex As Exception
            ' Display Error Message in status Bar
            stsLabel.Text = "Error: Make sure to use numeric values! EX. '3' "
            lblAmountClassA.Text = "Error" 'Display Error in Calculations box
            lblAmountClassB.Text = "Error" ' ""
            lblAmountClassC.Text = "Error" ' ""
            lblTotalAmount.Text = "Error" ' ""
        End Try
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        lblAmountClassA.Text = String.Empty 'Clears the calculation box
        lblAmountClassB.Text = String.Empty ' ""
        lblAmountClassC.Text = String.Empty ' ""
        lblTotalAmount.Text = String.Empty ' ""
        textboxClassA.Text = "0" 'Sets the textbox where user enter tickest to 0
        textboxClassB.Text = "0" ' ""
        textboxClassC.Text = "0" ' ""
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close() 'Close the application
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class
