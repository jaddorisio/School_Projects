﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.textboxClassA = New System.Windows.Forms.TextBox()
        Me.textboxClassB = New System.Windows.Forms.TextBox()
        Me.textboxClassC = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.lblTotalAmount = New System.Windows.Forms.Label()
        Me.lblAmountClassB = New System.Windows.Forms.Label()
        Me.lblAmountClassC = New System.Windows.Forms.Label()
        Me.lblAmountClassA = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.btnGenrateProfit = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.stsErrorMessage = New System.Windows.Forms.StatusStrip()
        Me.stsLabel = New System.Windows.Forms.ToolStripStatusLabel()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.stsErrorMessage.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.textboxClassA)
        Me.GroupBox1.Controls.Add(Me.textboxClassB)
        Me.GroupBox1.Controls.Add(Me.textboxClassC)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Location = New System.Drawing.Point(30, 37)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(248, 209)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Tickets Sold"
        '
        'textboxClassA
        '
        Me.textboxClassA.Location = New System.Drawing.Point(118, 82)
        Me.textboxClassA.Name = "textboxClassA"
        Me.textboxClassA.Size = New System.Drawing.Size(100, 22)
        Me.textboxClassA.TabIndex = 6
        Me.textboxClassA.Text = "0"
        '
        'textboxClassB
        '
        Me.textboxClassB.Location = New System.Drawing.Point(118, 127)
        Me.textboxClassB.Name = "textboxClassB"
        Me.textboxClassB.Size = New System.Drawing.Size(100, 22)
        Me.textboxClassB.TabIndex = 7
        Me.textboxClassB.Text = "0"
        '
        'textboxClassC
        '
        Me.textboxClassC.Location = New System.Drawing.Point(118, 173)
        Me.textboxClassC.Name = "textboxClassC"
        Me.textboxClassC.Size = New System.Drawing.Size(100, 22)
        Me.textboxClassC.TabIndex = 8
        Me.textboxClassC.Text = "0"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(40, 176)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(55, 17)
        Me.Label4.TabIndex = 4
        Me.Label4.Text = "Class C"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(40, 132)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(55, 17)
        Me.Label3.TabIndex = 3
        Me.Label3.Text = "Class B"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(40, 35)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(178, 34)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Enter the number of tickets" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "for each class of seats."
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(40, 87)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(55, 17)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Class A"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.lblTotalAmount)
        Me.GroupBox2.Controls.Add(Me.lblAmountClassB)
        Me.GroupBox2.Controls.Add(Me.lblAmountClassC)
        Me.GroupBox2.Controls.Add(Me.lblAmountClassA)
        Me.GroupBox2.Controls.Add(Me.Label8)
        Me.GroupBox2.Controls.Add(Me.Label7)
        Me.GroupBox2.Controls.Add(Me.Label6)
        Me.GroupBox2.Controls.Add(Me.Label5)
        Me.GroupBox2.Location = New System.Drawing.Point(319, 37)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(248, 209)
        Me.GroupBox2.TabIndex = 5
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Revenue Generated"
        '
        'lblTotalAmount
        '
        Me.lblTotalAmount.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblTotalAmount.Location = New System.Drawing.Point(109, 174)
        Me.lblTotalAmount.Name = "lblTotalAmount"
        Me.lblTotalAmount.Size = New System.Drawing.Size(133, 23)
        Me.lblTotalAmount.TabIndex = 6
        '
        'lblAmountClassB
        '
        Me.lblAmountClassB.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblAmountClassB.Location = New System.Drawing.Point(121, 87)
        Me.lblAmountClassB.Name = "lblAmountClassB"
        Me.lblAmountClassB.Size = New System.Drawing.Size(100, 23)
        Me.lblAmountClassB.TabIndex = 15
        '
        'lblAmountClassC
        '
        Me.lblAmountClassC.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblAmountClassC.Location = New System.Drawing.Point(121, 121)
        Me.lblAmountClassC.Name = "lblAmountClassC"
        Me.lblAmountClassC.Size = New System.Drawing.Size(100, 23)
        Me.lblAmountClassC.TabIndex = 14
        '
        'lblAmountClassA
        '
        Me.lblAmountClassA.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblAmountClassA.Location = New System.Drawing.Point(121, 52)
        Me.lblAmountClassA.Name = "lblAmountClassA"
        Me.lblAmountClassA.Size = New System.Drawing.Size(100, 23)
        Me.lblAmountClassA.TabIndex = 13
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(6, 176)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(101, 17)
        Me.Label8.TabIndex = 12
        Me.Label8.Text = "Total Revenue"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(48, 121)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(55, 17)
        Me.Label7.TabIndex = 11
        Me.Label7.Text = "Class C"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(48, 87)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(55, 17)
        Me.Label6.TabIndex = 10
        Me.Label6.Text = "Class B"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(48, 52)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(55, 17)
        Me.Label5.TabIndex = 9
        Me.Label5.Text = "Class A"
        '
        'btnGenrateProfit
        '
        Me.btnGenrateProfit.Location = New System.Drawing.Point(71, 278)
        Me.btnGenrateProfit.Name = "btnGenrateProfit"
        Me.btnGenrateProfit.Size = New System.Drawing.Size(177, 48)
        Me.btnGenrateProfit.TabIndex = 6
        Me.btnGenrateProfit.Text = "Calculate Revenue"
        Me.btnGenrateProfit.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(328, 278)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(90, 48)
        Me.btnClear.TabIndex = 7
        Me.btnClear.Text = "Clear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'stsErrorMessage
        '
        Me.stsErrorMessage.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.stsErrorMessage.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.stsLabel})
        Me.stsErrorMessage.Location = New System.Drawing.Point(0, 352)
        Me.stsErrorMessage.Name = "stsErrorMessage"
        Me.stsErrorMessage.Size = New System.Drawing.Size(579, 25)
        Me.stsErrorMessage.TabIndex = 8
        '
        'stsLabel
        '
        Me.stsLabel.Name = "stsLabel"
        Me.stsLabel.Size = New System.Drawing.Size(344, 20)
        Me.stsLabel.Text = "Remeber to fill in all textboxes with numeric value!"
        '
        'btnExit
        '
        Me.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnExit.Location = New System.Drawing.Point(450, 278)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(90, 48)
        Me.btnExit.TabIndex = 9
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AcceptButton = Me.btnGenrateProfit
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.btnExit
        Me.ClientSize = New System.Drawing.Size(579, 377)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.stsErrorMessage)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnGenrateProfit)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.MaximizeBox = False
        Me.Name = "Form1"
        Me.Text = "Stadium Seating"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.stsErrorMessage.ResumeLayout(False)
        Me.stsErrorMessage.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents textboxClassA As TextBox
    Friend WithEvents textboxClassB As TextBox
    Friend WithEvents textboxClassC As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents lblAmountClassB As Label
    Friend WithEvents lblAmountClassC As Label
    Friend WithEvents lblAmountClassA As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents lblTotalAmount As Label
    Friend WithEvents btnGenrateProfit As Button
    Friend WithEvents btnClear As Button
    Friend WithEvents stsErrorMessage As StatusStrip
    Friend WithEvents stsLabel As ToolStripStatusLabel
    Friend WithEvents btnExit As Button
End Class
