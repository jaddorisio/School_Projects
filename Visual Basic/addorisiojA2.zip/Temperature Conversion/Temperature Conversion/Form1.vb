﻿Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'Grabs the system time and display to label in bottome left
        lblSystemTime.Text = CType(TimeOfDay, String)
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        'Close the application
        Me.Close()
    End Sub

    Private Sub btnConvert_Click(sender As Object, e As EventArgs) Handles btnConvert.Click
        ' Decalre Celsius as a double variable to hold user input
        Dim Celsius As Double

        ' Exception block to display errors for non numeric user inputs 
        Try
            ' Convert user input into a double and store in Celsius variable
            Celsius = CDbl(textboxTempInput.Text)

            ' Use Conversion formula and converts fixed point scientific format 
            ' string to diplay to Fahrenhiet label
            lblFahrenheitResult.Text = ((1.8 * Celsius) + 32).ToString("F2") + " °F"
        Catch ex As Exception
            ' Display error message to status label and Fahrenheit Label
            ErrorLabel.Text = "Error Please use numeric values! ex. '234'"
            lblFahrenheitResult.Text = "Error"
        End Try

    End Sub

    Private Sub btnError_Click(sender As Object, e As EventArgs) Handles btnError.Click
        ' Sets the fahrenheit label to empty and textbox value to empty
        lblFahrenheitResult.Text = String.Empty
        textboxTempInput.Text = String.Empty
    End Sub
End Class
