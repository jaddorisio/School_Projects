﻿Public Class Form1
    Private Sub Calculate_Click(sender As Object, e As EventArgs) Handles Calculate.Click
        ' Dclaring variable to hold height, weight, and the bmi
        Dim BmiWeight As Double
        Dim BmiHeight As Double
        Dim BMI As Double

        ' Reseting status strip to show local computer time 
        StatusStrip.Text = CType(My.Computer.Clock.LocalTime, String)

        ' Intiating a exception statement to catch for
        ' numeric value errors 
        Try
            ' Converting height and weight to a decimal
            BmiHeight = CDec(TextBoxHeight.Text)
            BmiWeight = CDec(TextBoxWeight.Text)

            ' Calculating the bmi and storing in variable
            BMI = (BmiWeight * 703) / (BmiHeight ^ 2)

            ' An if statment to display an error when bmi is negative
            If BMI < 0 Then
                LAbelBMI_Message.Text = String.Empty
                LabelBMI.Text = "Error"
                StatusStrip.Text = "BMI cannot be under 0 check your measurements"
            End If

            ' an if statement to notify user there bmi is really high
            ' and might be an entry error
            If BMI > 50 Then
                StatusStrip.Text = "Check your meausrement they may be off"

            End If

            ' display bmi to a label and converts back to string
            LabelBMI.Text = BMI.ToString("F")

            ' a selcet case block to show the correct message that
            ' correspond with certain bmi values 
            Select Case BMI
                Case Is > 25
                    LAbelBMI_Message.Text = "Your BMI indicates your" & vbNewLine& &
                        "are overweight."
                Case 18.5 To 25
                    LAbelBMI_Message.Text = "Your BMI indicates your" & vbNewLine& &
                    "are optimal weight."
                Case Is < 18.5
                    LAbelBMI_Message.Text = "Your BMI indicates your" & vbNewLine& &
                     "are underweight."
            End Select


        Catch ex As Exception

            ' If an error is caught these message will display in the form
            LAbelBMI_Message.Text = "Error: Invalid Entry," & vbNewLine& &
            "Make sure you use numeric values"
            StatusStrip.Text = "Error: Invalid Entry," & vbNewLine& &
            "Make sure you use numeric values"
            LabelBMI.Text = "Error"
        End Try
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Shows the system time in status strip when
        ' the form launches
        StatusStrip.Text = CType(My.Computer.Clock.LocalTime, String)
    End Sub

    Private Sub ButtonExit_Click(sender As Object, e As EventArgs) Handles ButtonExit.Click
        ' Close the application
        Me.Close()
    End Sub

    Private Sub ButtonClear_Click(sender As Object, e As EventArgs) Handles ButtonClear.Click
        ' Reset the textboxes and bmi label back to zero
        TextBoxHeight.Text = "0"
        TextBoxWeight.Text = "0"
        LabelBMI.Text = "0"

        ' The select case message will return to normal welcome message
        LAbelBMI_Message.Text = "Welcome!" & vbNewLine& &
        "Curious to see your BMI?"
    End Sub
End Class
