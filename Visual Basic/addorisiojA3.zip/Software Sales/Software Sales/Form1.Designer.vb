﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.radioYearlyLicense = New System.Windows.Forms.RadioButton()
        Me.RadioOnePurchase = New System.Windows.Forms.RadioButton()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.CheckLevel3Tech = New System.Windows.Forms.CheckBox()
        Me.CheckOnSiteTraining = New System.Windows.Forms.CheckBox()
        Me.CheckCloudBackup = New System.Windows.Forms.CheckBox()
        Me.ButtonCalculate = New System.Windows.Forms.Button()
        Me.ButtonClear = New System.Windows.Forms.Button()
        Me.ButtonExit = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.LabelCostOfOptionalFeautures = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.LabelCostOfLicense = New System.Windows.Forms.Label()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.GroupBox1.Controls.Add(Me.radioYearlyLicense)
        Me.GroupBox1.Controls.Add(Me.RadioOnePurchase)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 34)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(203, 151)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Licensing Options"
        '
        'radioYearlyLicense
        '
        Me.radioYearlyLicense.AutoSize = True
        Me.radioYearlyLicense.Location = New System.Drawing.Point(19, 51)
        Me.radioYearlyLicense.Name = "radioYearlyLicense"
        Me.radioYearlyLicense.Size = New System.Drawing.Size(122, 21)
        Me.radioYearlyLicense.TabIndex = 1
        Me.radioYearlyLicense.TabStop = True
        Me.radioYearlyLicense.Text = "Yearly License"
        Me.radioYearlyLicense.UseVisualStyleBackColor = True
        '
        'RadioOnePurchase
        '
        Me.RadioOnePurchase.AutoSize = True
        Me.RadioOnePurchase.Location = New System.Drawing.Point(19, 79)
        Me.RadioOnePurchase.Name = "RadioOnePurchase"
        Me.RadioOnePurchase.Size = New System.Drawing.Size(156, 21)
        Me.RadioOnePurchase.TabIndex = 2
        Me.RadioOnePurchase.TabStop = True
        Me.RadioOnePurchase.Text = "One-Time Purchase"
        Me.RadioOnePurchase.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.GroupBox2.Controls.Add(Me.CheckLevel3Tech)
        Me.GroupBox2.Controls.Add(Me.CheckOnSiteTraining)
        Me.GroupBox2.Controls.Add(Me.CheckCloudBackup)
        Me.GroupBox2.Location = New System.Drawing.Point(258, 34)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(200, 151)
        Me.GroupBox2.TabIndex = 0
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Optional Features(yearly)"
        '
        'CheckLevel3Tech
        '
        Me.CheckLevel3Tech.AutoSize = True
        Me.CheckLevel3Tech.Location = New System.Drawing.Point(6, 37)
        Me.CheckLevel3Tech.Name = "CheckLevel3Tech"
        Me.CheckLevel3Tech.Size = New System.Drawing.Size(196, 21)
        Me.CheckLevel3Tech.TabIndex = 3
        Me.CheckLevel3Tech.Text = "Level-3 Technical Support"
        Me.CheckLevel3Tech.UseVisualStyleBackColor = True
        '
        'CheckOnSiteTraining
        '
        Me.CheckOnSiteTraining.AutoSize = True
        Me.CheckOnSiteTraining.Location = New System.Drawing.Point(6, 73)
        Me.CheckOnSiteTraining.Name = "CheckOnSiteTraining"
        Me.CheckOnSiteTraining.Size = New System.Drawing.Size(132, 21)
        Me.CheckOnSiteTraining.TabIndex = 4
        Me.CheckOnSiteTraining.Text = "On-site Training"
        Me.CheckOnSiteTraining.UseVisualStyleBackColor = True
        '
        'CheckCloudBackup
        '
        Me.CheckCloudBackup.AutoSize = True
        Me.CheckCloudBackup.Location = New System.Drawing.Point(6, 108)
        Me.CheckCloudBackup.Name = "CheckCloudBackup"
        Me.CheckCloudBackup.Size = New System.Drawing.Size(117, 21)
        Me.CheckCloudBackup.TabIndex = 5
        Me.CheckCloudBackup.Text = "Cloud Backup"
        Me.CheckCloudBackup.UseVisualStyleBackColor = True
        '
        'ButtonCalculate
        '
        Me.ButtonCalculate.Location = New System.Drawing.Point(61, 327)
        Me.ButtonCalculate.Name = "ButtonCalculate"
        Me.ButtonCalculate.Size = New System.Drawing.Size(92, 41)
        Me.ButtonCalculate.TabIndex = 7
        Me.ButtonCalculate.Text = "Calculate"
        Me.ButtonCalculate.UseVisualStyleBackColor = True
        '
        'ButtonClear
        '
        Me.ButtonClear.Location = New System.Drawing.Point(187, 327)
        Me.ButtonClear.Name = "ButtonClear"
        Me.ButtonClear.Size = New System.Drawing.Size(92, 41)
        Me.ButtonClear.TabIndex = 8
        Me.ButtonClear.Text = "&Clear"
        Me.ButtonClear.UseVisualStyleBackColor = True
        '
        'ButtonExit
        '
        Me.ButtonExit.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.ButtonExit.Location = New System.Drawing.Point(306, 327)
        Me.ButtonExit.Name = "ButtonExit"
        Me.ButtonExit.Size = New System.Drawing.Size(92, 41)
        Me.ButtonExit.TabIndex = 9
        Me.ButtonExit.Text = "Exit"
        Me.ButtonExit.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(24, 35)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(172, 17)
        Me.Label1.TabIndex = 4
        Me.Label1.Text = "Cost of software licensing:"
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.LabelCostOfOptionalFeautures)
        Me.GroupBox3.Controls.Add(Me.Label3)
        Me.GroupBox3.Controls.Add(Me.LabelCostOfLicense)
        Me.GroupBox3.Controls.Add(Me.Label1)
        Me.GroupBox3.Cursor = System.Windows.Forms.Cursors.Default
        Me.GroupBox3.Location = New System.Drawing.Point(61, 202)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(320, 100)
        Me.GroupBox3.TabIndex = 6
        Me.GroupBox3.TabStop = False
        '
        'LabelCostOfOptionalFeautures
        '
        Me.LabelCostOfOptionalFeautures.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LabelCostOfOptionalFeautures.Location = New System.Drawing.Point(215, 60)
        Me.LabelCostOfOptionalFeautures.Name = "LabelCostOfOptionalFeautures"
        Me.LabelCostOfOptionalFeautures.Size = New System.Drawing.Size(88, 17)
        Me.LabelCostOfOptionalFeautures.TabIndex = 7
        Me.LabelCostOfOptionalFeautures.Text = "$0.00"
        Me.LabelCostOfOptionalFeautures.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(24, 60)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(166, 17)
        Me.Label3.TabIndex = 6
        Me.Label3.Text = "Cost of optional features:"
        '
        'LabelCostOfLicense
        '
        Me.LabelCostOfLicense.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LabelCostOfLicense.Location = New System.Drawing.Point(215, 35)
        Me.LabelCostOfLicense.Name = "LabelCostOfLicense"
        Me.LabelCostOfLicense.Size = New System.Drawing.Size(88, 17)
        Me.LabelCostOfLicense.TabIndex = 5
        Me.LabelCostOfLicense.Text = "$0.00"
        Me.LabelCostOfLicense.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Form
        '
        Me.AcceptButton = Me.ButtonCalculate
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.ButtonExit
        Me.ClientSize = New System.Drawing.Size(470, 408)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.ButtonExit)
        Me.Controls.Add(Me.ButtonClear)
        Me.Controls.Add(Me.ButtonCalculate)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.MaximizeBox = False
        Me.Name = "Form"
        Me.Text = "Software Licensing"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents radioYearlyLicense As RadioButton
    Friend WithEvents RadioOnePurchase As RadioButton
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents CheckLevel3Tech As CheckBox
    Friend WithEvents CheckOnSiteTraining As CheckBox
    Friend WithEvents CheckCloudBackup As CheckBox
    Friend WithEvents ButtonCalculate As Button
    Friend WithEvents ButtonClear As Button
    Friend WithEvents ButtonExit As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents LabelCostOfOptionalFeautures As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents LabelCostOfLicense As Label
End Class
