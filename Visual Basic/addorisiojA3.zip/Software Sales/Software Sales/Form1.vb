﻿Public Class Form
    ' Variable declared in public class to be used through out all private subclasses
    ' Decarling variable to keep track of total cost
    Dim LicenseCost As Integer
    Dim OptionalFeautureCost As Integer

    ' Declaring price of each option as constants
    Const YearlyLicensePrice As Integer = 5000
    Const OneTimePurchasePrice As Integer = 20000
    Const Level3TechPrice As Integer = 3500
    Const OnSiteTrainingPrice As Integer = 2000
    Const CloudBackupPrice As Integer = 300
    Private Sub ButtonCalculate_Click(sender As Object, e As EventArgs) Handles ButtonCalculate.Click

        ' Initializing accumlative variables
        LicenseCost = 0
        OptionalFeautureCost = 0

        ' Nested If structue to control order of operation
        ' check to see if "Yearly Radio button" is ticked
        If radioYearlyLicense.Checked Then
            LicenseCost += YearlyLicensePrice

            ' Proceeds to see what checkboxes have been checked
            ' and if return as true add the correct price to the
            ' correct accumalative variable 
            If CheckLevel3Tech.Checked Then
                OptionalFeautureCost += Level3TechPrice
            End If

            If CheckOnSiteTraining.Checked Then
                OptionalFeautureCost += OnSiteTrainingPrice
            End If

            If CheckCloudBackup.Checked Then
                OptionalFeautureCost += CloudBackupPrice
            End If


            ' If the previous radio button was not selected this
            ' check to see if "one purchase" button was ticked
        ElseIf RadioOnePurchase.Checked Then
            LicenseCost += OneTimePurchasePrice

            ' Proceeds to see what checkboxes have been checked
            ' and if return as true add the correct price to the
            ' correct accumalative variable 
            If CheckLevel3Tech.Checked Then
                OptionalFeautureCost += Level3TechPrice
            End If

            If CheckOnSiteTraining.Checked Then
                OptionalFeautureCost += OnSiteTrainingPrice
            End If
            If CheckCloudBackup.Checked Then
                OptionalFeautureCost += CloudBackupPrice
            End If

            ' This checks to see if both radio buttons are not ticked
        ElseIf (radioYearlyLicense.Checked And RadioOnePurchase.Checked) = False Then
            ' Display the sum of purchase in the display label as "$0.00"
            LabelCostOfLicense.Text = "$0.00"
            LabelCostOfOptionalFeautures.Text = "$0.00"

            ' This if stucture checks to see if any checkboxes
            ' have been ticked while the radio buttons are not ticked
            ' and display correct error message.
            If (CheckLevel3Tech.Checked Or CheckOnSiteTraining.Checked) = True Then
                MessageBox.Show("No License Selceted!" & vbNewLine& &
                     "Must purchase License to obtain Optional Features")
            ElseIf CheckCloudBackup.Checked = True Then
                MessageBox.Show("No License Selceted!" & vbNewLine& &
                     "Must purchase License to obtain Optional Features!")
            Else
                MessageBox.Show("No License Selceted! ")
            End If
        End If




        ' Display the total of selections and display them
        ' to there corresponding label
        LabelCostOfLicense.Text = LicenseCost.ToString("C")
        LabelCostOfOptionalFeautures.Text = OptionalFeautureCost.ToString("C")

        ' Reset the accumaltive variable back to 0 to
        ' prevent overcharges
        LicenseCost = 0
        OptionalFeautureCost = 0


    End Sub

    Private Sub ButtonExit_Click(sender As Object, e As EventArgs) Handles ButtonExit.Click
        ' Close Application
        Me.Close()
    End Sub

    Private Sub ButtonClear_Click(sender As Object, e As EventArgs) Handles ButtonClear.Click
        ' reset all the radio buttons and checkboxes
        ' to unticked 
        radioYearlyLicense.Checked = False
        RadioOnePurchase.Checked = False
        CheckCloudBackup.Checked = False
        CheckLevel3Tech.Checked = False
        CheckOnSiteTraining.Checked = False

        ' Sets the accumlative variable back to 0
        LicenseCost = 0
        OptionalFeautureCost = 0

        'Has the display label show "$0.00"
        LabelCostOfLicense.Text = "$0.00"
        LabelCostOfOptionalFeautures.Text = "$0.00"

    End Sub

    Private Sub Form_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class
