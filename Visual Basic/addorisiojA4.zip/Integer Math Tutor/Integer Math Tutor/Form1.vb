﻿Public Class Form1
    ' Declaring Variable to create and hold
    ' Random numbers, Also a variable to hold correct 
    ' answer
    Dim Answer As Integer
    Dim RandomNumber1 As Integer
    Dim RandomNumber2 As Integer
    Dim RandomHolder As New Random

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles ButtonNextProblem.Click
        ' Create 2 random numbers
        RandomNumber1 = RandomHolder.Next(100) + 20
        RandomNumber2 = RandomHolder.Next(100) + 20

        ' If statement to follow procedures of the 
        ' selected radio buttons, and display problem
        ' on the screen and hold the answer 

        If RadioButtonAddition.Checked Then
            LabelRandomProblem.Text = (RandomNumber1 & " + " & RandomNumber2 & " =")
            Answer = CInt(RandomNumber1 + RandomNumber2)
        ElseIf RadioButtonDivision.Checked Then

            ' While loop to make sure that the 2 random
            ' numbers are divisible 
            Do While RandomNumber1 Mod RandomNumber2 <> 0
                RandomNumber2 = RandomHolder.Next(100) + 20
            Loop


            LabelRandomProblem.Text = (RandomNumber1 & " / " & RandomNumber2 & " =")
            Answer = CInt(RandomNumber1 / RandomNumber2)

        ElseIf RadioButtonMultiplication.Checked Then
            LabelRandomProblem.Text = (RandomNumber1 & " * " & RandomNumber2 & " =")
            Answer = CInt(RandomNumber1 * RandomNumber2)
        ElseIf RadioButtonSubtraction.Checked Then
            LabelRandomProblem.Text = (RandomNumber1 & " - " & RandomNumber2 & " =")
            Answer = CInt(RandomNumber1 - RandomNumber2)
        End If

        'Empty textbox and message label for correct/incorrect answer
        TextBoxUserInput.Text = String.Empty
        LabelResult.Text = String.Empty
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles ButtonCheckAnswer.Click
        ' Exception statment to make sure that
        ' the user input is numeric
        Try
            ' If statement to display whether or not 
            ' the user inputed the correct answer
            If CInt(TextBoxUserInput.Text) = Answer Then
                LabelResult.ForeColor = Color.Green
                LabelResult.Text = "Correct Answer"
            ElseIf CInt(TextBoxUserInput.Text) <> Answer Then
                LabelResult.ForeColor = Color.Red
                LabelResult.Text = "Incorrect Answer"
            End If
        Catch
            ' Display error message
            LabelResult.ForeColor = Color.Red
            LabelResult.Text = "Error"
            TextBoxUserInput.Text = "Error"
            MessageBox.Show("Invalid Input: Numeric Values Required Try again..")
        End Try
    End Sub
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' same structure in next problem button, it automaticly
        ' loads an addition problem when the user launches the
        ' application

        RadioButtonAddition.Select()

        RandomNumber1 = RandomHolder.Next(100) + 20
        RandomNumber2 = RandomHolder.Next(100) + 20

        If RadioButtonAddition.Checked Then
            LabelRandomProblem.Text = (RandomNumber1 & " + " & RandomNumber2 & " =")
            Answer = CInt(RandomNumber1 + RandomNumber2)
        ElseIf RadioButtonDivision.Checked Then

            Do While RandomNumber1 Mod RandomNumber2 <> 0
                RandomNumber2 = RandomHolder.Next(100) + 20
            Loop


            LabelRandomProblem.Text = (RandomNumber1 & " / " & RandomNumber2 & " =")
            Answer = CInt(RandomNumber1 / RandomNumber2)

        ElseIf RadioButtonMultiplication.Checked Then
            LabelRandomProblem.Text = (RandomNumber1 & " * " & RandomNumber2 & " =")
            Answer = CInt(RandomNumber1 * RandomNumber2)
        ElseIf RadioButtonSubtraction.Checked Then
            LabelRandomProblem.Text = (RandomNumber1 & " - " & RandomNumber2 & " =")
            Answer = CInt(RandomNumber1 - RandomNumber2)
        End If
    End Sub


End Class
