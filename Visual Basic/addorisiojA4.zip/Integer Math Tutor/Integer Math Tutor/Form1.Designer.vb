﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.RadioButtonAddition = New System.Windows.Forms.RadioButton()
        Me.RadioButtonSubtraction = New System.Windows.Forms.RadioButton()
        Me.RadioButtonMultiplication = New System.Windows.Forms.RadioButton()
        Me.RadioButtonDivision = New System.Windows.Forms.RadioButton()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.LabelRandomProblem = New System.Windows.Forms.Label()
        Me.TextBoxUserInput = New System.Windows.Forms.TextBox()
        Me.ButtonCheckAnswer = New System.Windows.Forms.Button()
        Me.ButtonNextProblem = New System.Windows.Forms.Button()
        Me.LabelResult = New System.Windows.Forms.Label()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.GroupBox1.Controls.Add(Me.RadioButtonDivision)
        Me.GroupBox1.Controls.Add(Me.RadioButtonMultiplication)
        Me.GroupBox1.Controls.Add(Me.RadioButtonSubtraction)
        Me.GroupBox1.Controls.Add(Me.RadioButtonAddition)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 0)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(512, 77)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Choose an Integer Operation"
        '
        'GroupBox2
        '
        Me.GroupBox2.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.GroupBox2.Controls.Add(Me.LabelResult)
        Me.GroupBox2.Controls.Add(Me.ButtonNextProblem)
        Me.GroupBox2.Controls.Add(Me.ButtonCheckAnswer)
        Me.GroupBox2.Controls.Add(Me.TextBoxUserInput)
        Me.GroupBox2.Controls.Add(Me.LabelRandomProblem)
        Me.GroupBox2.Controls.Add(Me.Label1)
        Me.GroupBox2.Location = New System.Drawing.Point(12, 83)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(512, 145)
        Me.GroupBox2.TabIndex = 1
        Me.GroupBox2.TabStop = False
        '
        'RadioButtonAddition
        '
        Me.RadioButtonAddition.AutoSize = True
        Me.RadioButtonAddition.Location = New System.Drawing.Point(30, 26)
        Me.RadioButtonAddition.Name = "RadioButtonAddition"
        Me.RadioButtonAddition.Size = New System.Drawing.Size(80, 21)
        Me.RadioButtonAddition.TabIndex = 0
        Me.RadioButtonAddition.TabStop = True
        Me.RadioButtonAddition.Text = "Addition"
        Me.RadioButtonAddition.UseVisualStyleBackColor = True
        '
        'RadioButtonSubtraction
        '
        Me.RadioButtonSubtraction.AutoSize = True
        Me.RadioButtonSubtraction.Location = New System.Drawing.Point(141, 26)
        Me.RadioButtonSubtraction.Name = "RadioButtonSubtraction"
        Me.RadioButtonSubtraction.Size = New System.Drawing.Size(101, 21)
        Me.RadioButtonSubtraction.TabIndex = 1
        Me.RadioButtonSubtraction.TabStop = True
        Me.RadioButtonSubtraction.Text = "Subtraction"
        Me.RadioButtonSubtraction.UseVisualStyleBackColor = True
        '
        'RadioButtonMultiplication
        '
        Me.RadioButtonMultiplication.AutoSize = True
        Me.RadioButtonMultiplication.Location = New System.Drawing.Point(267, 26)
        Me.RadioButtonMultiplication.Name = "RadioButtonMultiplication"
        Me.RadioButtonMultiplication.Size = New System.Drawing.Size(110, 21)
        Me.RadioButtonMultiplication.TabIndex = 2
        Me.RadioButtonMultiplication.TabStop = True
        Me.RadioButtonMultiplication.Text = "Multiplication"
        Me.RadioButtonMultiplication.UseVisualStyleBackColor = True
        '
        'RadioButtonDivision
        '
        Me.RadioButtonDivision.AutoSize = True
        Me.RadioButtonDivision.Location = New System.Drawing.Point(409, 26)
        Me.RadioButtonDivision.Name = "RadioButtonDivision"
        Me.RadioButtonDivision.Size = New System.Drawing.Size(78, 21)
        Me.RadioButtonDivision.TabIndex = 3
        Me.RadioButtonDivision.TabStop = True
        Me.RadioButtonDivision.Text = "Division"
        Me.RadioButtonDivision.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(0, 27)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(508, 17)
        Me.Label1.TabIndex = 4
        Me.Label1.Text = "Please type in your answer to the following math problem. Integer answers only:"
        '
        'LabelRandomProblem
        '
        Me.LabelRandomProblem.AutoSize = True
        Me.LabelRandomProblem.Location = New System.Drawing.Point(59, 62)
        Me.LabelRandomProblem.Name = "LabelRandomProblem"
        Me.LabelRandomProblem.Size = New System.Drawing.Size(51, 17)
        Me.LabelRandomProblem.TabIndex = 5
        Me.LabelRandomProblem.Text = "Label2"
        '
        'TextBoxUserInput
        '
        Me.TextBoxUserInput.Location = New System.Drawing.Point(167, 59)
        Me.TextBoxUserInput.Name = "TextBoxUserInput"
        Me.TextBoxUserInput.Size = New System.Drawing.Size(130, 22)
        Me.TextBoxUserInput.TabIndex = 6
        '
        'ButtonCheckAnswer
        '
        Me.ButtonCheckAnswer.Location = New System.Drawing.Point(349, 77)
        Me.ButtonCheckAnswer.Name = "ButtonCheckAnswer"
        Me.ButtonCheckAnswer.Size = New System.Drawing.Size(157, 29)
        Me.ButtonCheckAnswer.TabIndex = 7
        Me.ButtonCheckAnswer.Text = "Check Your Answer"
        Me.ButtonCheckAnswer.UseVisualStyleBackColor = True
        '
        'ButtonNextProblem
        '
        Me.ButtonNextProblem.Location = New System.Drawing.Point(349, 113)
        Me.ButtonNextProblem.Name = "ButtonNextProblem"
        Me.ButtonNextProblem.Size = New System.Drawing.Size(157, 29)
        Me.ButtonNextProblem.TabIndex = 8
        Me.ButtonNextProblem.Text = "&Next Problem"
        Me.ButtonNextProblem.UseVisualStyleBackColor = True
        '
        'LabelResult
        '
        Me.LabelResult.AutoSize = True
        Me.LabelResult.Location = New System.Drawing.Point(59, 89)
        Me.LabelResult.Name = "LabelResult"
        Me.LabelResult.Size = New System.Drawing.Size(0, 17)
        Me.LabelResult.TabIndex = 9
        '
        'Form1
        '
        Me.AcceptButton = Me.ButtonCheckAnswer
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(536, 237)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.MaximizeBox = False
        Me.Name = "Form1"
        Me.Text = "Integer Math Tutor"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents RadioButtonDivision As RadioButton
    Friend WithEvents RadioButtonMultiplication As RadioButton
    Friend WithEvents RadioButtonSubtraction As RadioButton
    Friend WithEvents RadioButtonAddition As RadioButton
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents ButtonNextProblem As Button
    Friend WithEvents ButtonCheckAnswer As Button
    Friend WithEvents TextBoxUserInput As TextBox
    Friend WithEvents LabelRandomProblem As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents LabelResult As Label
End Class
