﻿Public Class Form1
    ' Determine the reistration fee and number of days based on
    ' the selected index of the workshops list box.
    Sub SetDaysAndRegistrationFees(ByRef intRegistration As Integer, ByRef intDays As Integer)
        ' If structure is used to detemine selectecd index
        ' and store correct values
        If ListBoxWorkshop.SelectedIndex = 0 Then
            intRegistration = 595
            intDays = 3
        ElseIf ListBoxWorkshop.SelectedIndex = 1 Then
            intRegistration = 695
            intDays = 3
        ElseIf ListBoxWorkshop.SelectedIndex = 2 Then
            intRegistration = 995
            intDays = 3
        ElseIf ListBoxWorkshop.SelectedIndex = 3 Then
            intRegistration = 1295
            intDays = 5
        ElseIf ListBoxWorkshop.SelectedIndex = 4 Then
            intRegistration = 395
            intDays = 1
        Else
            MessageBox.Show("Please Select a workshop")
            ListBoxLocation.SelectedIndex = -1
            intDays = 0
            intRegistration = 0
        End If
    End Sub
    ' Set the logding fee per day based on the selected index of the
    ' location list box.
    Sub SetLodgingFeePerDay(ByRef intLodgingCost As Integer)
        ' If structure is used to detemine selectecd index
        ' and store correct values
        If ListBoxLocation.SelectedIndex = 0 Then
            intLodgingCost = 95
        ElseIf ListBoxLocation.SelectedIndex = 1 Then
            intLodgingCost = 125
        ElseIf ListBoxLocation.SelectedIndex = 2 Then
            intLodgingCost = 110
        ElseIf ListBoxLocation.SelectedIndex = 3 Then
            intLodgingCost = 100
        ElseIf ListBoxLocation.SelectedIndex = 4 Then
            intLodgingCost = 92
        ElseIf ListBoxLocation.SelectedIndex = 5 Then
            intLodgingCost = 90
            ' Display message if only one list box is selected
        Else
            MessageBox.Show("Please Select a Location")
            ListBoxWorkshop.SelectedIndex = -1
            intLodgingCost = 0
        End If
    End Sub
    Private Sub ButtonExit_Click(sender As Object, e As EventArgs) Handles ButtonExit.Click
        ' Close the application
        Me.Close()
    End Sub

    Private Sub ButtonReset_Click(sender As Object, e As EventArgs) Handles ButtonReset.Click
        ' Reset so that nothing is selected and the
        ' cost list box is cleared
        ListBoxLocation.SelectedIndex = -1
        ListBoxCost.Items.Clear()
        ListBoxWorkshop.SelectedIndex = -1
        LabelTotalCost.Text = "$0.00"
    End Sub

    Private Sub ButtonAddWorkShop_Click(sender As Object, e As EventArgs) Handles ButtonAddWorkShop.Click
        ' Declaring variable to hold cost and days of 
        ' the workshop
        Dim intWorkshopCost As Integer
        Dim intRegistration As Integer
        Dim intDays As Integer
        Dim intLodgingCost As Integer

        ' Intialize variable as 0
        intDays = 0
        intRegistration = 0
        intLodgingCost = 0
        intWorkshopCost = 0

        'Calling Lodging Fee Procedure
        SetLodgingFeePerDay(intLodgingCost)
        'Calling Days and Registration Procedure 
        SetDaysAndRegistrationFees(intRegistration, intDays)


        ' Store the total cost of the selected workshop
        ' and adds the cost to the 3rd listbox, Only if 
        ' Index are in the selected range
        If ListBoxWorkshop.SelectedIndex >= 0 And ListBoxWorkshop.SelectedIndex <= 4 Then
            If ListBoxLocation.SelectedIndex >= 0 And ListBoxLocation.SelectedIndex <= 5 Then
                intWorkshopCost = intRegistration + (intDays * intLodgingCost)
                ListBoxCost.Items.Add(intWorkshopCost.ToString("C"))
            End If
        End If



        ' reset the variable back to 0
        intDays = 0
        intRegistration = 0
        intLodgingCost = 0
        intWorkshopCost = 0


    End Sub

    Private Sub ButtonCalculateTotal_Click(sender As Object, e As EventArgs) Handles ButtonCalculateTotal.Click
        ' Declaring variables to hold correct values
        ' in order to total all the cost in the
        ' 3rd listbox
        Dim Count As Integer
        Dim Total As Integer
        Dim ItemValue As String

        ' Gets the amount of items in the list and
        ' subtracts 1 to get the max index of cost listbox
        Count = ListBoxCost.Items.Count
        Count -= 1
        Total = 0

        ' A while loop that continues to add each cost together 
        ' until the count variable is less than 0
        Do

            ' Store the selected index as a string
            ItemValue = CType((ListBoxCost.Items(Count)), String)

            ' Strips the dollar sign from the item
            ItemValue.TrimStart(CType("$", Char()))

            ' Adds the string to total after being
            ' converted to a integer, subtracts 1 from the count
            ' to go onto the next item
            Total += CInt(ItemValue)
            Count -= 1
        Loop Until Count < 0

        ' Display total cost as a string in currency format 
        LabelTotalCost.Text = Total.ToString("C")

    End Sub
End Class
