﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.ListBoxWorkshop = New System.Windows.Forms.ListBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.ListBoxCost = New System.Windows.Forms.ListBox()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.ListBoxLocation = New System.Windows.Forms.ListBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.LabelTotalCost = New System.Windows.Forms.Label()
        Me.ButtonAddWorkShop = New System.Windows.Forms.Button()
        Me.ButtonCalculateTotal = New System.Windows.Forms.Button()
        Me.ButtonReset = New System.Windows.Forms.Button()
        Me.ButtonExit = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.ListBoxWorkshop)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 12)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(162, 127)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Pick a Workshop"
        '
        'ListBoxWorkshop
        '
        Me.ListBoxWorkshop.FormattingEnabled = True
        Me.ListBoxWorkshop.ItemHeight = 16
        Me.ListBoxWorkshop.Items.AddRange(New Object() {"Handleing Stress", "Time Management", "Supervision Skills", "Neogotiation", "How to Interview"})
        Me.ListBoxWorkshop.Location = New System.Drawing.Point(6, 21)
        Me.ListBoxWorkshop.Name = "ListBoxWorkshop"
        Me.ListBoxWorkshop.Size = New System.Drawing.Size(150, 100)
        Me.ListBoxWorkshop.TabIndex = 1
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.ListBoxCost)
        Me.GroupBox2.Location = New System.Drawing.Point(348, 12)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(156, 127)
        Me.GroupBox2.TabIndex = 0
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "List of Cost"
        '
        'ListBoxCost
        '
        Me.ListBoxCost.FormattingEnabled = True
        Me.ListBoxCost.ItemHeight = 16
        Me.ListBoxCost.Location = New System.Drawing.Point(6, 21)
        Me.ListBoxCost.Name = "ListBoxCost"
        Me.ListBoxCost.Size = New System.Drawing.Size(144, 100)
        Me.ListBoxCost.TabIndex = 3
        Me.ListBoxCost.Tag = ""
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.ListBoxLocation)
        Me.GroupBox3.Location = New System.Drawing.Point(180, 12)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(162, 127)
        Me.GroupBox3.TabIndex = 0
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Pick a Location"
        '
        'ListBoxLocation
        '
        Me.ListBoxLocation.FormattingEnabled = True
        Me.ListBoxLocation.ItemHeight = 16
        Me.ListBoxLocation.Items.AddRange(New Object() {"Austin", "Chicago", "Dallas", "Orlando", "Phoenix", "Raleigh"})
        Me.ListBoxLocation.Location = New System.Drawing.Point(6, 21)
        Me.ListBoxLocation.Name = "ListBoxLocation"
        Me.ListBoxLocation.Size = New System.Drawing.Size(150, 100)
        Me.ListBoxLocation.TabIndex = 2
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.Label1.Location = New System.Drawing.Point(159, 163)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(96, 20)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Total Cost :"
        '
        'LabelTotalCost
        '
        Me.LabelTotalCost.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LabelTotalCost.Location = New System.Drawing.Point(260, 163)
        Me.LabelTotalCost.Name = "LabelTotalCost"
        Me.LabelTotalCost.Size = New System.Drawing.Size(105, 24)
        Me.LabelTotalCost.TabIndex = 2
        Me.LabelTotalCost.Text = "$0.00"
        '
        'ButtonAddWorkShop
        '
        Me.ButtonAddWorkShop.Location = New System.Drawing.Point(12, 210)
        Me.ButtonAddWorkShop.Name = "ButtonAddWorkShop"
        Me.ButtonAddWorkShop.Size = New System.Drawing.Size(118, 35)
        Me.ButtonAddWorkShop.TabIndex = 4
        Me.ButtonAddWorkShop.Text = "&Add Workshop"
        Me.ButtonAddWorkShop.UseVisualStyleBackColor = True
        '
        'ButtonCalculateTotal
        '
        Me.ButtonCalculateTotal.Location = New System.Drawing.Point(136, 210)
        Me.ButtonCalculateTotal.Name = "ButtonCalculateTotal"
        Me.ButtonCalculateTotal.Size = New System.Drawing.Size(118, 35)
        Me.ButtonCalculateTotal.TabIndex = 5
        Me.ButtonCalculateTotal.Text = "&Calculate Total"
        Me.ButtonCalculateTotal.UseVisualStyleBackColor = True
        '
        'ButtonReset
        '
        Me.ButtonReset.Location = New System.Drawing.Point(260, 210)
        Me.ButtonReset.Name = "ButtonReset"
        Me.ButtonReset.Size = New System.Drawing.Size(118, 35)
        Me.ButtonReset.TabIndex = 6
        Me.ButtonReset.Text = "&Reset"
        Me.ButtonReset.UseVisualStyleBackColor = True
        '
        'ButtonExit
        '
        Me.ButtonExit.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.ButtonExit.Location = New System.Drawing.Point(384, 210)
        Me.ButtonExit.Name = "ButtonExit"
        Me.ButtonExit.Size = New System.Drawing.Size(118, 35)
        Me.ButtonExit.TabIndex = 7
        Me.ButtonExit.Text = "&Exit"
        Me.ButtonExit.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AcceptButton = Me.ButtonAddWorkShop
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.ButtonExit
        Me.ClientSize = New System.Drawing.Size(516, 261)
        Me.Controls.Add(Me.ButtonExit)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.ButtonReset)
        Me.Controls.Add(Me.ButtonCalculateTotal)
        Me.Controls.Add(Me.ButtonAddWorkShop)
        Me.Controls.Add(Me.LabelTotalCost)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox1)
        Me.MaximizeBox = False
        Me.Name = "Form1"
        Me.Text = "Workshop Selector"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox3.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents ListBoxWorkshop As ListBox
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents ListBoxCost As ListBox
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents ListBoxLocation As ListBox
    Friend WithEvents Label1 As Label
    Friend WithEvents LabelTotalCost As Label
    Friend WithEvents ButtonAddWorkShop As Button
    Friend WithEvents ButtonCalculateTotal As Button
    Friend WithEvents ButtonReset As Button
    Friend WithEvents ButtonExit As Button
End Class
