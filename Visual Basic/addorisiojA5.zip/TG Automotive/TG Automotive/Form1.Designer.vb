﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.CheckBoxOilChange = New System.Windows.Forms.CheckBox()
        Me.CheckBoxLubeJob = New System.Windows.Forms.CheckBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.CheckBoxRadiatorFlush = New System.Windows.Forms.CheckBox()
        Me.CheckBoxTransmissionFlush = New System.Windows.Forms.CheckBox()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.CheckBoxTireRotation = New System.Windows.Forms.CheckBox()
        Me.CheckBoxReplaceMuffler = New System.Windows.Forms.CheckBox()
        Me.CheckBoxInspection = New System.Windows.Forms.CheckBox()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.TextBoxParts = New System.Windows.Forms.TextBox()
        Me.TextBoxLabor = New System.Windows.Forms.TextBox()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.LabelTotalCost = New System.Windows.Forms.Label()
        Me.LabelServicesAndLaborCost = New System.Windows.Forms.Label()
        Me.LabelPartsCost = New System.Windows.Forms.Label()
        Me.LabelTaxCost = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.ButtonCalculate = New System.Windows.Forms.Button()
        Me.ButtonClear = New System.Windows.Forms.Button()
        Me.ButtonExit = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.CheckBoxOilChange)
        Me.GroupBox1.Controls.Add(Me.CheckBoxLubeJob)
        Me.GroupBox1.Location = New System.Drawing.Point(33, 12)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(248, 102)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Oil and Lubrication"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(151, 35)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(44, 17)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "36.00"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(151, 62)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(44, 17)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "28.00"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'CheckBoxOilChange
        '
        Me.CheckBoxOilChange.AutoSize = True
        Me.CheckBoxOilChange.Location = New System.Drawing.Point(20, 34)
        Me.CheckBoxOilChange.Name = "CheckBoxOilChange"
        Me.CheckBoxOilChange.Size = New System.Drawing.Size(100, 21)
        Me.CheckBoxOilChange.TabIndex = 1
        Me.CheckBoxOilChange.Text = "Oil Change"
        Me.CheckBoxOilChange.UseVisualStyleBackColor = True
        '
        'CheckBoxLubeJob
        '
        Me.CheckBoxLubeJob.AutoSize = True
        Me.CheckBoxLubeJob.Location = New System.Drawing.Point(20, 61)
        Me.CheckBoxLubeJob.Name = "CheckBoxLubeJob"
        Me.CheckBoxLubeJob.Size = New System.Drawing.Size(89, 21)
        Me.CheckBoxLubeJob.TabIndex = 2
        Me.CheckBoxLubeJob.Text = "Lube Job"
        Me.CheckBoxLubeJob.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(191, 35)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(44, 17)
        Me.Label3.TabIndex = 3
        Me.Label3.Text = "50.00"
        '
        'GroupBox2
        '
        Me.GroupBox2.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.GroupBox2.Controls.Add(Me.Label3)
        Me.GroupBox2.Controls.Add(Me.Label4)
        Me.GroupBox2.Controls.Add(Me.CheckBoxRadiatorFlush)
        Me.GroupBox2.Controls.Add(Me.CheckBoxTransmissionFlush)
        Me.GroupBox2.Location = New System.Drawing.Point(327, 12)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(248, 102)
        Me.GroupBox2.TabIndex = 0
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Radiator and Transmission"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(191, 62)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(52, 17)
        Me.Label4.TabIndex = 4
        Me.Label4.Text = "120.00"
        '
        'CheckBoxRadiatorFlush
        '
        Me.CheckBoxRadiatorFlush.AutoSize = True
        Me.CheckBoxRadiatorFlush.Location = New System.Drawing.Point(24, 34)
        Me.CheckBoxRadiatorFlush.Name = "CheckBoxRadiatorFlush"
        Me.CheckBoxRadiatorFlush.Size = New System.Drawing.Size(122, 21)
        Me.CheckBoxRadiatorFlush.TabIndex = 3
        Me.CheckBoxRadiatorFlush.Text = "Radiator Flush"
        Me.CheckBoxRadiatorFlush.UseVisualStyleBackColor = True
        '
        'CheckBoxTransmissionFlush
        '
        Me.CheckBoxTransmissionFlush.AutoSize = True
        Me.CheckBoxTransmissionFlush.Location = New System.Drawing.Point(24, 61)
        Me.CheckBoxTransmissionFlush.Name = "CheckBoxTransmissionFlush"
        Me.CheckBoxTransmissionFlush.Size = New System.Drawing.Size(152, 21)
        Me.CheckBoxTransmissionFlush.TabIndex = 4
        Me.CheckBoxTransmissionFlush.Text = "Transmission Flush"
        Me.CheckBoxTransmissionFlush.UseVisualStyleBackColor = True
        '
        'GroupBox3
        '
        Me.GroupBox3.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.GroupBox3.Controls.Add(Me.Label5)
        Me.GroupBox3.Controls.Add(Me.Label6)
        Me.GroupBox3.Controls.Add(Me.Label7)
        Me.GroupBox3.Controls.Add(Me.CheckBoxTireRotation)
        Me.GroupBox3.Controls.Add(Me.CheckBoxReplaceMuffler)
        Me.GroupBox3.Controls.Add(Me.CheckBoxInspection)
        Me.GroupBox3.Location = New System.Drawing.Point(33, 135)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(248, 144)
        Me.GroupBox3.TabIndex = 0
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Miscellaneus"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(165, 33)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(44, 17)
        Me.Label5.TabIndex = 1
        Me.Label5.Text = "15.00"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(165, 60)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(52, 17)
        Me.Label6.TabIndex = 2
        Me.Label6.Text = "200.00"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(165, 87)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(44, 17)
        Me.Label7.TabIndex = 3
        Me.Label7.Text = "20.00"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'CheckBoxTireRotation
        '
        Me.CheckBoxTireRotation.AutoSize = True
        Me.CheckBoxTireRotation.Location = New System.Drawing.Point(20, 86)
        Me.CheckBoxTireRotation.Name = "CheckBoxTireRotation"
        Me.CheckBoxTireRotation.Size = New System.Drawing.Size(112, 21)
        Me.CheckBoxTireRotation.TabIndex = 7
        Me.CheckBoxTireRotation.Text = "Tire Rotation"
        Me.CheckBoxTireRotation.UseVisualStyleBackColor = True
        '
        'CheckBoxReplaceMuffler
        '
        Me.CheckBoxReplaceMuffler.AutoSize = True
        Me.CheckBoxReplaceMuffler.Location = New System.Drawing.Point(20, 59)
        Me.CheckBoxReplaceMuffler.Name = "CheckBoxReplaceMuffler"
        Me.CheckBoxReplaceMuffler.Size = New System.Drawing.Size(129, 21)
        Me.CheckBoxReplaceMuffler.TabIndex = 6
        Me.CheckBoxReplaceMuffler.Text = "Replace Muffler"
        Me.CheckBoxReplaceMuffler.UseVisualStyleBackColor = True
        '
        'CheckBoxInspection
        '
        Me.CheckBoxInspection.AutoSize = True
        Me.CheckBoxInspection.Location = New System.Drawing.Point(20, 32)
        Me.CheckBoxInspection.Name = "CheckBoxInspection"
        Me.CheckBoxInspection.Size = New System.Drawing.Size(94, 21)
        Me.CheckBoxInspection.TabIndex = 5
        Me.CheckBoxInspection.Text = "Inspection"
        Me.CheckBoxInspection.UseVisualStyleBackColor = True
        '
        'GroupBox4
        '
        Me.GroupBox4.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.GroupBox4.Controls.Add(Me.Label11)
        Me.GroupBox4.Controls.Add(Me.Label10)
        Me.GroupBox4.Controls.Add(Me.Label8)
        Me.GroupBox4.Controls.Add(Me.Label9)
        Me.GroupBox4.Controls.Add(Me.TextBoxParts)
        Me.GroupBox4.Controls.Add(Me.TextBoxLabor)
        Me.GroupBox4.Location = New System.Drawing.Point(327, 135)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(248, 144)
        Me.GroupBox4.TabIndex = 0
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Parts and Labor"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(189, 87)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(57, 17)
        Me.Label11.TabIndex = 10
        Me.Label11.Text = "Minutes"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(21, 87)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(45, 17)
        Me.Label10.TabIndex = 9
        Me.Label10.Text = "Labor"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(19, 50)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(41, 17)
        Me.Label8.TabIndex = 1
        Me.Label8.Text = "Parts"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(190, 50)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(52, 17)
        Me.Label9.TabIndex = 2
        Me.Label9.Text = "Dollars"
        '
        'TextBoxParts
        '
        Me.TextBoxParts.Location = New System.Drawing.Point(76, 47)
        Me.TextBoxParts.Name = "TextBoxParts"
        Me.TextBoxParts.Size = New System.Drawing.Size(100, 22)
        Me.TextBoxParts.TabIndex = 8
        Me.TextBoxParts.Text = "0.00"
        '
        'TextBoxLabor
        '
        Me.TextBoxLabor.Location = New System.Drawing.Point(76, 84)
        Me.TextBoxLabor.Name = "TextBoxLabor"
        Me.TextBoxLabor.Size = New System.Drawing.Size(100, 22)
        Me.TextBoxLabor.TabIndex = 9
        Me.TextBoxLabor.Text = "0"
        '
        'GroupBox5
        '
        Me.GroupBox5.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.GroupBox5.Controls.Add(Me.LabelTotalCost)
        Me.GroupBox5.Controls.Add(Me.LabelServicesAndLaborCost)
        Me.GroupBox5.Controls.Add(Me.LabelPartsCost)
        Me.GroupBox5.Controls.Add(Me.LabelTaxCost)
        Me.GroupBox5.Controls.Add(Me.Label12)
        Me.GroupBox5.Controls.Add(Me.Label13)
        Me.GroupBox5.Controls.Add(Me.Label14)
        Me.GroupBox5.Controls.Add(Me.Label15)
        Me.GroupBox5.Location = New System.Drawing.Point(30, 294)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(545, 135)
        Me.GroupBox5.TabIndex = 11
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "Summary of Charges"
        '
        'LabelTotalCost
        '
        Me.LabelTotalCost.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LabelTotalCost.Location = New System.Drawing.Point(433, 84)
        Me.LabelTotalCost.Name = "LabelTotalCost"
        Me.LabelTotalCost.Size = New System.Drawing.Size(100, 23)
        Me.LabelTotalCost.TabIndex = 15
        Me.LabelTotalCost.Text = "$0.00"
        '
        'LabelServicesAndLaborCost
        '
        Me.LabelServicesAndLaborCost.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LabelServicesAndLaborCost.Location = New System.Drawing.Point(192, 45)
        Me.LabelServicesAndLaborCost.Name = "LabelServicesAndLaborCost"
        Me.LabelServicesAndLaborCost.Size = New System.Drawing.Size(100, 23)
        Me.LabelServicesAndLaborCost.TabIndex = 12
        Me.LabelServicesAndLaborCost.Text = "$0.00"
        '
        'LabelPartsCost
        '
        Me.LabelPartsCost.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LabelPartsCost.Location = New System.Drawing.Point(192, 84)
        Me.LabelPartsCost.Name = "LabelPartsCost"
        Me.LabelPartsCost.Size = New System.Drawing.Size(100, 23)
        Me.LabelPartsCost.TabIndex = 13
        Me.LabelPartsCost.Text = "$0.00"
        '
        'LabelTaxCost
        '
        Me.LabelTaxCost.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LabelTaxCost.Location = New System.Drawing.Point(432, 45)
        Me.LabelTaxCost.Name = "LabelTaxCost"
        Me.LabelTaxCost.Size = New System.Drawing.Size(100, 23)
        Me.LabelTaxCost.TabIndex = 14
        Me.LabelTaxCost.Text = "$0.00"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(28, 45)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(131, 17)
        Me.Label12.TabIndex = 11
        Me.Label12.Text = "Services and Labor"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(28, 84)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(41, 17)
        Me.Label13.TabIndex = 12
        Me.Label13.Text = "Parts"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(300, 45)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(101, 17)
        Me.Label14.TabIndex = 13
        Me.Label14.Text = "Tax ( on parts)"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(300, 84)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(75, 17)
        Me.Label15.TabIndex = 14
        Me.Label15.Text = "Total Fees"
        '
        'ButtonCalculate
        '
        Me.ButtonCalculate.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.ButtonCalculate.Location = New System.Drawing.Point(53, 444)
        Me.ButtonCalculate.Name = "ButtonCalculate"
        Me.ButtonCalculate.Size = New System.Drawing.Size(154, 41)
        Me.ButtonCalculate.TabIndex = 10
        Me.ButtonCalculate.Text = "&Calculate Total"
        Me.ButtonCalculate.UseVisualStyleBackColor = False
        '
        'ButtonClear
        '
        Me.ButtonClear.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.ButtonClear.Location = New System.Drawing.Point(268, 444)
        Me.ButtonClear.Name = "ButtonClear"
        Me.ButtonClear.Size = New System.Drawing.Size(101, 41)
        Me.ButtonClear.TabIndex = 11
        Me.ButtonClear.Text = "&Reset"
        Me.ButtonClear.UseVisualStyleBackColor = False
        '
        'ButtonExit
        '
        Me.ButtonExit.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.ButtonExit.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.ButtonExit.Location = New System.Drawing.Point(428, 444)
        Me.ButtonExit.Name = "ButtonExit"
        Me.ButtonExit.Size = New System.Drawing.Size(97, 41)
        Me.ButtonExit.TabIndex = 12
        Me.ButtonExit.Text = "&Exit"
        Me.ButtonExit.UseVisualStyleBackColor = False
        '
        'Form1
        '
        Me.AcceptButton = Me.ButtonCalculate
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.CancelButton = Me.ButtonExit
        Me.ClientSize = New System.Drawing.Size(604, 510)
        Me.Controls.Add(Me.ButtonExit)
        Me.Controls.Add(Me.ButtonClear)
        Me.Controls.Add(Me.ButtonCalculate)
        Me.Controls.Add(Me.GroupBox5)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox4)
        Me.Controls.Add(Me.GroupBox1)
        Me.MaximizeBox = False
        Me.Name = "Form1"
        Me.Text = "TG Automotive"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox5.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents Label3 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents CheckBoxOilChange As CheckBox
    Friend WithEvents CheckBoxLubeJob As CheckBox
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents Label4 As Label
    Friend WithEvents CheckBoxRadiatorFlush As CheckBox
    Friend WithEvents CheckBoxTransmissionFlush As CheckBox
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents CheckBoxTireRotation As CheckBox
    Friend WithEvents CheckBoxReplaceMuffler As CheckBox
    Friend WithEvents CheckBoxInspection As CheckBox
    Friend WithEvents GroupBox4 As GroupBox
    Friend WithEvents TextBoxParts As TextBox
    Friend WithEvents TextBoxLabor As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents GroupBox5 As GroupBox
    Friend WithEvents LabelTotalCost As Label
    Friend WithEvents LabelServicesAndLaborCost As Label
    Friend WithEvents LabelPartsCost As Label
    Friend WithEvents LabelTaxCost As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents ButtonCalculate As Button
    Friend WithEvents ButtonClear As Button
    Friend WithEvents ButtonExit As Button
End Class
