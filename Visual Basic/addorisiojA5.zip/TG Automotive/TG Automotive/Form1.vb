﻿Public Class Form1
    ' Verify that the two inputs values are valid
    ' numbers and neither is less than zero.
    Function ValidateInputs(Labor As String, Parts As String) As Boolean

        'Declaring varibale to hold textbox values 
        ' and boolean holders.
        Dim ExceptionParts As Decimal
        Dim ExceptionLabor As Decimal
        Dim BooleanHolder1 As Boolean
        Dim BooleanHolder2 As Boolean

        ' 2 Exception statements that attemp to convert the value 
        ' of labor and parts textbox to a decimal. If converison happens
        ' The boolen holder is set to true and if not is set to false
        ' An error message will display for the improperly filled textbox
        Try
            ExceptionLabor = CDec(Labor)
            BooleanHolder1 = True
        Catch ex As Exception
            MessageBox.Show("Please use numeric Value For Labor")
            BooleanHolder1 = False
            TextBoxLabor.Text = String.Empty
        End Try

        Try
            ExceptionParts = CDec(Parts)
            BooleanHolder2 = True
        Catch ex As Exception
            MessageBox.Show("Please use numeric Value For Parts")
            BooleanHolder2 = False
            TextBoxParts.Text = String.Empty
        End Try

        ' If conversion succeful test to make sure values are not negative
        ' if less than zero sets the true booleanholder to false 

        If ExceptionLabor < 0 Then
            BooleanHolder1 = False
            MessageBox.Show("Value Must Be Postive for Labor!!")
            TextBoxLabor.Text = String.Empty
        End If
        If ExceptionParts < 0 Then
            BooleanHolder2 = False
            MessageBox.Show("Value Must Be Postive For Parts!!")
            TextBoxParts.Text = String.Empty
        End If
        ' If statement that returns true to the function if 
        ' both boolean holder are true 
        If BooleanHolder1 = True And BooleanHolder2 = True Then
            Return True
        Else
            Return False
        End If

    End Function

    ' Calculate all oil and lubrication charges.
    Function CalcOilLubeCharges() As Decimal
        'Declaring Accumlative variable
        Dim Total As Decimal

        ' If structure that addes cost to accumlitive variable 
        ' if correct checkbox is true, then return the total
        If CheckBoxOilChange.Checked Then
            Total += 36
        End If
        If CheckBoxLubeJob.Checked Then
            Total += 28
        End If
        Return Total
    End Function
    ' Calculate radiator and transmission flush Charges.
    Function CalcFlushCharges() As Decimal
        'Declaring Accumlative variable
        Dim Total As Decimal

        ' If structure that addes cost to accumlitive variable 
        ' if correct checkbox is true, then return the total
        If CheckBoxRadiatorFlush.Checked Then
            Total += 50
        End If
        If CheckBoxTransmissionFlush.Checked Then
            Total += 120
        End If
        Return Total
    End Function
    ' Calculate inspection, muffler, and tire
    ' rotation charges.
    Function CalcMiscCharges() As Decimal
        'Declaring Accumlative variable
        Dim Total As Decimal

        ' If structure that addes cost to accumlitive variable 
        ' if correct checkbox is true, then return the total
        If CheckBoxReplaceMuffler.Checked Then
            Total += 200
        End If
        If CheckBoxTireRotation.Checked Then
            Total += 20
        End If
        If CheckBoxInspection.Checked Then
            Total += 15
        End If
        Return Total
    End Function
    ' Calculate and display the total of all charges
    ' including labor, parts, and services.
    Sub CalculateTotalCharges(ByVal ServiceOilLube As Decimal, ServiceFlush As Decimal,
                              ByVal ServiceMisc As Decimal, ByVal LaborTime As Decimal,
                              ByVal PartsCost As Decimal)
        ' Decalres varibale to hold certain costs
        Dim LaborCost As Decimal
        Dim ServiceTotal As Decimal
        Dim TaxCost As Decimal
        Dim TotalFees As Decimal

        If LaborTime > 0 And PartsCost > 0 Then
            ' Equation to find MA tax on parts
            TaxCost = CDec(PartsCost * 0.0625)

            ' Gets the total of all services
            ServiceTotal = ServiceFlush + ServiceOilLube + ServiceMisc

            LaborCost = LaborTime * 1 ' Shows What to do if LAbor Charge was a differnt amout 

            ' Gets the total of all cost
            TotalFees = TaxCost + ServiceTotal + LaborCost + PartsCost

            ' Display each cost in currency format
            LabelTaxCost.Text = TaxCost.ToString("C")
            LabelPartsCost.Text = PartsCost.ToString("C")
            LabelServicesAndLaborCost.Text = (ServiceTotal + LaborCost).ToString("C")
            LabelTotalCost.Text = TotalFees.ToString("C")

        Else
            MessageBox.Show("Please Enter Values Greater than 0 in parts and Labor Box ")
        End If

    End Sub
    ' Sets the oil group back to uncheck
    Sub ClearOilLube()
        ' Sets Checkbox to unchecked 
        CheckBoxOilChange.Checked = False
        CheckBoxLubeJob.Checked = False
    End Sub
    ' Sets the flush group back to unched 
    Sub ClearFlushes()
        ' Sets Checkbox to unchecked 
        CheckBoxRadiatorFlush.Checked = False
        CheckBoxTransmissionFlush.Checked = False
    End Sub
    ' Reset Misc Group back to uncheckd
    Sub ClearMisc()
        ' Sets Checkbox to unchecked 
        CheckBoxReplaceMuffler.Checked = False
        CheckBoxTireRotation.Checked = False
        CheckBoxInspection.Checked = False
    End Sub
    ' Sets parts and labor back to 0
    ' Bonus: Resets labels back to 0
    Sub ClearOther()
        ' Restore label back to $0.00
        LabelPartsCost.Text = "$0.00"
        LabelServicesAndLaborCost.Text = "$0.00"
        LabelTaxCost.Text = "$0.00"
        LabelTotalCost.Text = "$0.00"

        'Resent the text box to orginal form
        TextBoxLabor.Text = "0"
        TextBoxParts.Text = "0.00"

    End Sub
    Private Sub ButtonCalculate_Click(sender As Object, e As EventArgs) Handles ButtonCalculate.Click
        ' Declaring the service bundle variables 
        Dim ServiceBundle1 As Decimal
        Dim ServiceBundle2 As Decimal
        Dim ServiceBundle3 As Decimal

        ' Use procedure to calculate the total
        ' of certain services and stores in bundle variables 
        ServiceBundle1 = CalcOilLubeCharges()
        ServiceBundle2 = CalcFlushCharges()
        ServiceBundle3 = CalcMiscCharges()



        ' If structure that carrys out the CalcTotal prodcedure
        ' If the validate input returns True 
        If ValidateInputs(TextBoxLabor.Text, TextBoxParts.Text) = True Then
            CalculateTotalCharges(ServiceBundle1, ServiceBundle2, ServiceBundle3,
                CDec(TextBoxLabor.Text), CDec(TextBoxParts.Text))
        End If

    End Sub

    Private Sub ButtonClear_Click(sender As Object, e As EventArgs) Handles ButtonClear.Click
        ' Calls multiple procedure to reset everything back to 0
        ClearFlushes()
        ClearMisc()
        ClearOilLube()
        ClearOther()

    End Sub

    Private Sub ButtonExit_Click(sender As Object, e As EventArgs) Handles ButtonExit.Click
        ' Closes the application
        Me.Close()
    End Sub
End Class
