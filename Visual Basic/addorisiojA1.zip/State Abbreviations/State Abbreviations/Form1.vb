﻿Public Class lblProgram

    Private Sub btnVirginia_Click(sender As Object, e As EventArgs) Handles btnVirginia.Click
        lblAbbreviations.Visible = True 'Make lblAbbreviations visible to user
        lblAbbreviations.Text = "VA" ' Changes text in lblAbbreviations to "VA"
    End Sub

    Private Sub btnSouthCarolina_Click(sender As Object, e As EventArgs) Handles btnSouthCarolina.Click
        lblAbbreviations.Visible = True 'Make lblAbbreviations visible to user
        lblAbbreviations.Text = "SC" ' Changes text in lblAbbreviations to "SC"
    End Sub

    Private Sub btnAlabama_Click(sender As Object, e As EventArgs) Handles btnAlabama.Click
        lblAbbreviations.Visible = True 'Make lblAbbreviations visible to user
        lblAbbreviations.Text = "AL" ' Changes text in lblAbbreviations to "AL"
    End Sub

    Private Sub btnNorthCarolina_Click(sender As Object, e As EventArgs) Handles btnNorthCarolina.Click
        lblAbbreviations.Visible = True 'Make lblAbbreviations visible to user
        lblAbbreviations.Text = "NC" ' Changes text in lblAbbreviations to "NC"
    End Sub

    Private Sub btnGeorgia_Click(sender As Object, e As EventArgs) Handles btnGeorgia.Click
        lblAbbreviations.Visible = True 'Make lblAbbreviations visible to user
        lblAbbreviations.Text = "GA" ' Changes text in lblAbbreviations to "GA"
    End Sub

    Private Sub btnFlorida_Click(sender As Object, e As EventArgs) Handles btnFlorida.Click
        lblAbbreviations.Visible = True 'Make lblAbbreviations visible to user
        lblAbbreviations.Text = "FL" ' Changes text in lblAbbreviations to "FL"
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close() ' closes the application
    End Sub

    Private Sub btnHide_Click(sender As Object, e As EventArgs) Handles btnHide.Click
        lblAbbreviations.Visible = False ''hides lblAbbreviations from the user
        lblAbbreviations.Text = "" ' Changes text in lblAbbreviations to ""
    End Sub
End Class
