﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class lblProgram
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.lblTitle = New System.Windows.Forms.Label()
        Me.btnVirginia = New System.Windows.Forms.Button()
        Me.btnAlabama = New System.Windows.Forms.Button()
        Me.btnSouthCarolina = New System.Windows.Forms.Button()
        Me.btnNorthCarolina = New System.Windows.Forms.Button()
        Me.btnFlorida = New System.Windows.Forms.Button()
        Me.btnGeorgia = New System.Windows.Forms.Button()
        Me.lblAbbreviations = New System.Windows.Forms.Label()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.lblHeader = New System.Windows.Forms.Label()
        Me.btnHide = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'lblTitle
        '
        Me.lblTitle.AutoSize = True
        Me.lblTitle.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.lblTitle.Location = New System.Drawing.Point(104, 32)
        Me.lblTitle.Name = "lblTitle"
        Me.lblTitle.Size = New System.Drawing.Size(263, 20)
        Me.lblTitle.TabIndex = 0
        Me.lblTitle.Text = "Learn these states abbreviations!!"
        '
        'btnVirginia
        '
        Me.btnVirginia.Location = New System.Drawing.Point(86, 86)
        Me.btnVirginia.Name = "btnVirginia"
        Me.btnVirginia.Size = New System.Drawing.Size(119, 29)
        Me.btnVirginia.TabIndex = 1
        Me.btnVirginia.Text = "Virginia"
        Me.btnVirginia.UseVisualStyleBackColor = True
        '
        'btnAlabama
        '
        Me.btnAlabama.Location = New System.Drawing.Point(86, 203)
        Me.btnAlabama.Name = "btnAlabama"
        Me.btnAlabama.Size = New System.Drawing.Size(119, 29)
        Me.btnAlabama.TabIndex = 2
        Me.btnAlabama.Text = "Alabama"
        Me.btnAlabama.UseVisualStyleBackColor = True
        '
        'btnSouthCarolina
        '
        Me.btnSouthCarolina.Location = New System.Drawing.Point(86, 143)
        Me.btnSouthCarolina.Name = "btnSouthCarolina"
        Me.btnSouthCarolina.Size = New System.Drawing.Size(119, 29)
        Me.btnSouthCarolina.TabIndex = 3
        Me.btnSouthCarolina.Text = "South Carolina"
        Me.btnSouthCarolina.UseVisualStyleBackColor = True
        '
        'btnNorthCarolina
        '
        Me.btnNorthCarolina.Location = New System.Drawing.Point(269, 86)
        Me.btnNorthCarolina.Name = "btnNorthCarolina"
        Me.btnNorthCarolina.Size = New System.Drawing.Size(119, 29)
        Me.btnNorthCarolina.TabIndex = 4
        Me.btnNorthCarolina.Text = "North Carolina"
        Me.btnNorthCarolina.UseVisualStyleBackColor = True
        '
        'btnFlorida
        '
        Me.btnFlorida.Location = New System.Drawing.Point(269, 203)
        Me.btnFlorida.Name = "btnFlorida"
        Me.btnFlorida.Size = New System.Drawing.Size(119, 29)
        Me.btnFlorida.TabIndex = 5
        Me.btnFlorida.Text = "Florida"
        Me.btnFlorida.UseVisualStyleBackColor = True
        '
        'btnGeorgia
        '
        Me.btnGeorgia.Location = New System.Drawing.Point(269, 143)
        Me.btnGeorgia.Name = "btnGeorgia"
        Me.btnGeorgia.Size = New System.Drawing.Size(119, 29)
        Me.btnGeorgia.TabIndex = 6
        Me.btnGeorgia.Text = "Georgia"
        Me.btnGeorgia.UseVisualStyleBackColor = True
        '
        'lblAbbreviations
        '
        Me.lblAbbreviations.AutoSize = True
        Me.lblAbbreviations.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblAbbreviations.Font = New System.Drawing.Font("Lucida Console", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAbbreviations.Location = New System.Drawing.Point(201, 295)
        Me.lblAbbreviations.Name = "lblAbbreviations"
        Me.lblAbbreviations.Size = New System.Drawing.Size(2, 42)
        Me.lblAbbreviations.TabIndex = 7
        Me.lblAbbreviations.Visible = False
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(179, 352)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(121, 43)
        Me.btnExit.TabIndex = 8
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'lblHeader
        '
        Me.lblHeader.AutoSize = True
        Me.lblHeader.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.lblHeader.Location = New System.Drawing.Point(163, 266)
        Me.lblHeader.Name = "lblHeader"
        Me.lblHeader.Size = New System.Drawing.Size(150, 20)
        Me.lblHeader.TabIndex = 9
        Me.lblHeader.Text = "State Abbreviation:"
        '
        'btnHide
        '
        Me.btnHide.Location = New System.Drawing.Point(27, 295)
        Me.btnHide.Name = "btnHide"
        Me.btnHide.Size = New System.Drawing.Size(124, 42)
        Me.btnHide.TabIndex = 10
        Me.btnHide.Text = "Hide Abbreviation"
        Me.btnHide.UseVisualStyleBackColor = True
        '
        'lblProgram
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoSize = True
        Me.ClientSize = New System.Drawing.Size(485, 431)
        Me.Controls.Add(Me.btnHide)
        Me.Controls.Add(Me.lblHeader)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.lblAbbreviations)
        Me.Controls.Add(Me.btnGeorgia)
        Me.Controls.Add(Me.btnFlorida)
        Me.Controls.Add(Me.btnNorthCarolina)
        Me.Controls.Add(Me.btnSouthCarolina)
        Me.Controls.Add(Me.btnAlabama)
        Me.Controls.Add(Me.btnVirginia)
        Me.Controls.Add(Me.lblTitle)
        Me.MaximizeBox = False
        Me.Name = "lblProgram"
        Me.Text = "State Abbreviations"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblTitle As Label
    Friend WithEvents btnVirginia As Button
    Friend WithEvents btnAlabama As Button
    Friend WithEvents btnSouthCarolina As Button
    Friend WithEvents btnNorthCarolina As Button
    Friend WithEvents btnFlorida As Button
    Friend WithEvents btnGeorgia As Button
    Friend WithEvents lblAbbreviations As Label
    Friend WithEvents btnExit As Button
    Friend WithEvents lblHeader As Label
    Friend WithEvents btnHide As Button
End Class
