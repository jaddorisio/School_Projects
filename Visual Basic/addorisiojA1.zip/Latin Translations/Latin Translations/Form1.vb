﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnSinister.Click
        Label1.Visible = True 'Makes Label1 visible to user
        Label1.Text = "Left" ' Changes text in label1 to "left"
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close() ' Closes application
    End Sub

    Private Sub btnMedium_Click(sender As Object, e As EventArgs) Handles btnMedium.Click
        Label1.Visible = True 'Makes Label1 visible to user
        Label1.Text = "Middle" ' Changes text in label1 to "right"
    End Sub

    Private Sub btnDexter_Click(sender As Object, e As EventArgs) Handles btnDexter.Click
        Label1.Visible = True 'Makes Label1 visible to user
        Label1.Text = "Right" ' Changes text in label1 to "right"
    End Sub
End Class
